from .condor import condor_object, run_condor
